2D physics library Box2D 2.3 for usage in Python.

After installing please be sure to try out the testbed demos.
They require either pygame or pyglet and are available on the
homepage.

pybox2d homepage: http://pybox2d.googlecode.com
Box2D homepage: http://www.box2d.org


